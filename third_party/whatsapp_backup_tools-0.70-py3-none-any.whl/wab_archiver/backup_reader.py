import atexit
import contextlib
import io
import logging
import os
import plistlib
import shutil
import sqlite3
import tempfile
import typing

from shared.source_detection import WA_DATABASES_DIR_NAME

# ==============================================================================
# backup_reader.py — iPhone backup format parsing
# Knows nothing about WhatsApp schema; handles only the backup file structure.
# ==============================================================================

_WA_DOMAIN = "AppDomainGroup-group.net.whatsapp.WhatsApp.shared"
_WA_BUSINESS_DOMAIN = "AppDomainGroup-group.net.whatsapp.WhatsAppSMB.shared"

_IOS_AUXILIARY_DATABASES: list[tuple[list[str], str]] = [
    (["ExtChatDB/ExtChatDatabase.sqlite", "ExtChatDatabase.sqlite"], "ExtChatDatabase.sqlite"),
    (
        [
            "MessagingInfraDB_v2/MessagingInfraDatabase.sqlite",
            "MessagingInfraDB/MessagingInfraDatabase.sqlite",
            "MessagingInfraDatabase.sqlite",
        ],
        "MessagingInfraDatabase.sqlite",
    ),
    (["LID.sqlite"], "LID.sqlite"),
    (["CallHistory.sqlite"], "CallHistory.sqlite"),
    (["Labels.sqlite"], "Labels.sqlite"),
]


def _extract_file_safely(
    backup: typing.Any,
    relative_path: str,
    domain_like: str,
    output_filename: str,
    logger: logging.Logger,
) -> None:
    """
    Extract a single file from an encrypted backup while capturing 3rd-party stdout noise.
    Any stdout output (e.g. byte length warnings) is logged at DEBUG level.
    """
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        backup.extract_file(
            relative_path=relative_path,
            domain_like=domain_like,
            output_filename=output_filename,
        )
    output = buf.getvalue().strip()
    if output:
        logger.debug(f"iphone_backup_decrypt output for {relative_path}: {output}")


def _extract_auxiliary_databases_unencrypted(
    manifest_map: dict[str, str], output_dir: str, logger: logging.Logger
) -> None:
    """Extract optional auxiliary iOS databases if present in the backup manifest."""
    extracted_names: list[str] = []
    for candidates, target_name in _IOS_AUXILIARY_DATABASES:
        found_path = None
        for cand in candidates:
            if cand in manifest_map:
                found_path = cand
                break
        if found_path is not None:
            logger.debug(f"Extracting {target_name} from backup...")
            tmp = extract_to_temp(manifest_map, found_path, logger)
            _save_db_to_output(tmp, output_dir, target_name, logger)
            os.unlink(tmp)
            extracted_names.append(target_name)
    if extracted_names:
        logger.info(
            f"Extracted {len(extracted_names)} auxiliary databases: {', '.join(extracted_names)}."
        )


def _extract_auxiliary_databases_encrypted(
    backup: typing.Any, domain_like: str, output_dir: str, logger: logging.Logger
) -> None:
    """Decrypt optional auxiliary iOS databases if present in the encrypted backup."""
    extracted_names: list[str] = []
    for candidates, target_name in _IOS_AUXILIARY_DATABASES:
        extracted = False
        for cand in candidates:
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".sqlite")
            tmp.close()
            try:
                _extract_file_safely(
                    backup=backup,
                    relative_path=cand,
                    domain_like=domain_like,
                    output_filename=tmp.name,
                    logger=logger,
                )
                _save_db_to_output(tmp.name, output_dir, target_name, logger)
                os.unlink(tmp.name)
                logger.debug(f"Decrypted auxiliary database: {target_name}.")
                extracted_names.append(target_name)
                extracted = True
                break
            except FileNotFoundError:
                os.unlink(tmp.name)
        if not extracted:
            logger.debug(f"{target_name} not found in encrypted backup.")
    if extracted_names:
        logger.info(
            f"Decrypted {len(extracted_names)} auxiliary databases: {', '.join(extracted_names)}."
        )


def _raise_macos_fda_error(path: str, logger: logging.Logger) -> None:
    logger.error(
        f"Permission denied reading backup file — macOS blocked access to:\n"
        f"  {path}\n"
        f"Grant Full Disk Access to Terminal (or whichever app runs this script):\n"
        f"  System Settings → Privacy & Security → Full Disk Access → enable Terminal\n"
        f"Then re-run the command."
    )
    raise SystemExit(1)


def detect_encrypted(backup_dir: str, logger: logging.Logger) -> bool:
    """
    Return True if the iPhone backup is encrypted.
    Reads the IsEncrypted flag from Manifest.plist in the backup directory.
    """
    if not os.path.isdir(backup_dir):
        logger.error(f"--ios-backup path does not exist or is not a directory: {backup_dir}")
        raise SystemExit(1)

    info_path = os.path.join(backup_dir, "Info.plist")
    if not os.path.isfile(info_path):
        manifest_path = os.path.join(backup_dir, "Manifest.plist")
        if not os.path.isfile(manifest_path):
            logger.error(
                f"Neither Info.plist nor Manifest.plist found in: {backup_dir}\n"
                f"  Make sure --ios-backup points to the backup directory "
                f"(the folder that contains Manifest.db)."
            )
            raise SystemExit(1)
        plist_path = manifest_path
    else:
        plist_path = info_path

    try:
        with open(plist_path, "rb") as f:
            data = plistlib.load(f)
    except PermissionError:
        _raise_macos_fda_error(plist_path, logger)
    except plistlib.InvalidFileException as e:
        logger.error(f"Could not read {plist_path}: {e}\n  The file may be corrupt.")
        raise SystemExit(1)

    # Manifest.plist uses 'IsEncrypted'; Info.plist does not carry this flag.
    # If we only have Info.plist, fall back to checking Manifest.plist if present.
    is_encrypted = data.get("IsEncrypted", False)
    if not is_encrypted and plist_path == info_path:
        manifest_path = os.path.join(backup_dir, "Manifest.plist")
        if os.path.isfile(manifest_path):
            try:
                with open(manifest_path, "rb") as f:
                    manifest_data = plistlib.load(f)
            except PermissionError:
                _raise_macos_fda_error(manifest_path, logger)
            except plistlib.InvalidFileException as e:
                logger.error(f"Could not read {manifest_path}: {e}\n  The file may be corrupt.")
                raise SystemExit(1)
            is_encrypted = manifest_data.get("IsEncrypted", False)

    return bool(is_encrypted)


def build_manifest_map(
    backup_dir: str, logger: logging.Logger, domain: str = _WA_DOMAIN
) -> dict[str, str]:
    """
    Build a {relativePath: absolute_hash_file_path} map for all WhatsApp files
    in the backup. Reads Manifest.db once at startup; all subsequent lookups
    are O(1) dict access.

    Hash files are stored at <backup_dir>/<fileID[:2]>/<fileID>.
    """
    if not os.path.isdir(backup_dir):
        logger.error(f"--ios-backup path does not exist or is not a directory: {backup_dir}")
        raise SystemExit(1)

    manifest_db = os.path.join(backup_dir, "Manifest.db")
    if not os.path.isfile(manifest_db):
        logger.error(
            f"Manifest.db not found in: {backup_dir}\n"
            f"  Make sure --ios-backup points to the backup root directory."
        )
        raise SystemExit(1)

    try:
        with open(manifest_db, "rb"):
            pass
    except PermissionError:
        _raise_macos_fda_error(manifest_db, logger)
    with contextlib.closing(sqlite3.connect(manifest_db)) as conn:
        rows = conn.execute(
            "SELECT fileID, relativePath "
            "FROM Files "
            "WHERE domain = ? "
            "  AND relativePath IS NOT NULL",
            (domain,),
        ).fetchall()

    result = {}
    for file_id, relative_path in rows:
        abs_path = os.path.join(backup_dir, file_id[:2], file_id)
        result[relative_path] = abs_path

    return result


def extract_to_temp(
    manifest_map: dict[str, str], relative_path: str, logger: logging.Logger
) -> str:
    """
    Copy a single file from the backup hash tree to a NamedTemporaryFile.
    Returns the temp file path. Caller is responsible for deleting it on exit.

    Raises SystemExit with a clear message if the file is not in the manifest
    or the hash file does not exist on disk.
    """
    src = manifest_map.get(relative_path)
    if src is None:
        logger.error(
            f"'{relative_path}' not found in backup manifest.\n"
            f"  This file may not exist in the WhatsApp domain of this backup.\n"
            f"  If you use WhatsApp Business, add --business to your command."
        )
        raise SystemExit(1)

    if not os.path.isfile(src):
        logger.error(
            f"Backup hash file not found on disk: {src}\n  The backup may be incomplete or corrupt."
        )
        raise SystemExit(1)

    suffix = os.path.splitext(relative_path)[1] or ".tmp"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.close()
    shutil.copy2(src, tmp.name)
    return tmp.name


def _save_db_to_output(src: str, output_dir: str, filename: str, logger: logging.Logger) -> str:
    """Copy a SQLite file to the output folder; log at DEBUG if overwriting. Returns dest path."""
    os.makedirs(output_dir, exist_ok=True)
    dest = os.path.join(output_dir, filename)
    if os.path.exists(dest):
        logger.debug(f"Overwriting existing {os.path.normpath(dest)} with extracted database.")
    shutil.copy2(src, dest)
    return dest


def extract_plaintext(
    backup_dir: str,
    output_dir: str,
    ios_contacts_override: str | None,
    business: bool,
    logger: logging.Logger,
) -> tuple[dict, str, str | None]:
    """
    Extract WhatsApp files from a plaintext (unencrypted) iPhone backup.
    Returns (manifest_map, msgstore_path, ios_contacts_path).

    ChatStorage.sqlite is copied to output_dir for re-run support.
    ContactsV2.sqlite is extracted to a temp file (auto-deleted on exit).
    """
    domain = _WA_BUSINESS_DOMAIN if business else _WA_DOMAIN
    logger.info("Building manifest map from backup...")
    manifest_map = build_manifest_map(backup_dir, logger, domain=domain)
    if not manifest_map:
        logger.warning(
            f"Manifest map is empty — no WhatsApp files found in the backup at: "
            f"{backup_dir}\n"
            f"  Make sure --ios-backup points to the backup root directory "
            f"(the folder that contains Manifest.db), and that the backup "
            f"includes WhatsApp data."
        )
    else:
        logger.info(f"Manifest map built: {len(manifest_map)} WhatsApp file(s).")

    db_output_dir = os.path.join(output_dir, WA_DATABASES_DIR_NAME)
    logger.info("Extracting ChatStorage.sqlite from backup...")
    tmp_db = extract_to_temp(manifest_map, "ChatStorage.sqlite", logger)
    msgstore_path = _save_db_to_output(tmp_db, db_output_dir, "ChatStorage.sqlite", logger)
    os.unlink(tmp_db)

    ios_contacts_path = ios_contacts_override
    if ios_contacts_path is None:
        if manifest_map.get("ContactsV2.sqlite"):
            logger.info("Extracting ContactsV2.sqlite from backup...")
            tmp_contacts = extract_to_temp(manifest_map, "ContactsV2.sqlite", logger)
            ios_contacts_path = _save_db_to_output(
                tmp_contacts, db_output_dir, "ContactsV2.sqlite", logger
            )
            os.unlink(tmp_contacts)
        else:
            logger.warning("ContactsV2.sqlite not found in backup; proceeding without contacts.")

    _extract_auxiliary_databases_unencrypted(manifest_map, db_output_dir, logger)

    return manifest_map, msgstore_path, ios_contacts_path


def extract_encrypted(
    backup_dir: str,
    passphrase: str,
    output_dir: str,
    ios_contacts_override: str | None,
    business: bool,
    logger: logging.Logger,
) -> tuple[str, str | None, callable]:
    """
    Decrypt an encrypted iPhone backup and return a lazy media resolver.
    Returns (msgstore_path, ios_contacts_path, media_resolver).

    ChatStorage.sqlite is decrypted to output_dir for re-run support.
    ContactsV2.sqlite is decrypted to a temp file (auto-deleted on exit).
    Media files are decrypted on demand: media_resolver(relative_path) decrypts
    the file the first time it is requested and caches it in a temp dir
    (auto-deleted on exit). This means only the media that is actually referenced
    by the filtered query is decrypted.
    """
    try:
        from iphone_backup_decrypt import EncryptedBackup
    except ImportError:
        logger.error(
            "iphone-backup-decrypt is required for encrypted iOS backups but is not installed.\n"
            "  Run: pip install iphone-backup-decrypt"
        )
        raise SystemExit(1)

    logger.info("Unlocking encrypted backup...")
    try:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            backup = EncryptedBackup(backup_directory=backup_dir, passphrase=passphrase)
            backup.test_decryption()
        unlock_out = buf.getvalue().strip()
        if unlock_out:
            logger.debug(f"iphone_backup_decrypt unlock output: {unlock_out}")
    except ValueError as e:
        logger.error(f"Failed to unlock backup: {e}\n  Check that --ios-password is correct.")
        raise SystemExit(1)

    # Use a tight domain pattern that targets exactly one app.
    # DomainLike.WHATSAPP ("%net.whatsapp.%") is deliberately avoided — it
    # matches both regular and Business domains, which would mix their data.
    _domain = _WA_BUSINESS_DOMAIN if business else _WA_DOMAIN
    domain_like = f"%{_domain.split('-', 1)[1]}%"

    os.makedirs(output_dir, exist_ok=True)
    db_output_dir = os.path.join(output_dir, WA_DATABASES_DIR_NAME)

    # --- ChatStorage.sqlite ---
    logger.info("Decrypting ChatStorage.sqlite...")
    tmp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".sqlite")
    tmp_db.close()
    try:
        _extract_file_safely(
            backup=backup,
            relative_path="ChatStorage.sqlite",
            domain_like=domain_like,
            output_filename=tmp_db.name,
            logger=logger,
        )
    except FileNotFoundError:
        logger.error(
            "ChatStorage.sqlite not found in encrypted backup.\n"
            "  If you use WhatsApp Business, add --business to your command."
        )
        os.unlink(tmp_db.name)
        raise SystemExit(1)
    msgstore_path = _save_db_to_output(tmp_db.name, db_output_dir, "ChatStorage.sqlite", logger)
    os.unlink(tmp_db.name)

    # --- ContactsV2.sqlite ---
    ios_contacts_path = ios_contacts_override
    if ios_contacts_path is None:
        tmp_contacts = tempfile.NamedTemporaryFile(delete=False, suffix=".sqlite")
        tmp_contacts.close()
        try:
            _extract_file_safely(
                backup=backup,
                relative_path="ContactsV2.sqlite",
                domain_like=domain_like,
                output_filename=tmp_contacts.name,
                logger=logger,
            )
            ios_contacts_path = _save_db_to_output(
                tmp_contacts.name, db_output_dir, "ContactsV2.sqlite", logger
            )
            os.unlink(tmp_contacts.name)
            logger.info("Decrypted ContactsV2.sqlite.")
        except FileNotFoundError:
            logger.warning(
                "ContactsV2.sqlite not found in encrypted backup; proceeding without contacts."
            )
            os.unlink(tmp_contacts.name)

    _extract_auxiliary_databases_encrypted(backup, domain_like, db_output_dir, logger)

    # --- Lazy media resolver ---
    # Decrypt each media file on demand, caching in a temp dir.
    # Only files actually referenced by the (possibly filtered) query are touched.
    tmp_media_dir = tempfile.mkdtemp(prefix="wa_ios_media_")
    atexit.register(shutil.rmtree, tmp_media_dir, ignore_errors=True)
    cache: dict[str, str] = {}

    def _media_resolver(relative_path: str) -> str | None:
        if relative_path in cache:
            return cache[relative_path]
        dest = os.path.join(tmp_media_dir, *relative_path.split("/"))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        try:
            _extract_file_safely(
                backup=backup,
                relative_path=relative_path,
                domain_like=domain_like,
                output_filename=dest,
                logger=logger,
            )
        except FileNotFoundError:
            return None
        cache[relative_path] = dest
        return dest

    return msgstore_path, ios_contacts_path, _media_resolver
