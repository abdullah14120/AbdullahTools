import csv
import logging
import os
import posixpath
import re
import shutil
import sqlite3
import subprocess
import sys
import time

from .increment_merger import filter_active_increments
from .progress import ProgressReporter

_MSGSTORE_PATH = (
    "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Databases/msgstore.db.crypt15"
)
_MSGSTORE_BUSINESS_PATH = (
    "/storage/emulated/0/Android/media/com.whatsapp.w4b"
    "/WhatsApp Business/Databases/msgstore.db.crypt15"
)
_WA_MEDIA_ROOT = "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media"
_WA_BUSINESS_MEDIA_ROOT = (
    "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media"
)
_CONTACTS_URI = "content://com.android.contacts/data"
_CONTACTS_PROJECTION = "display_name:data1:data4:mimetype"

_TRANSIENT_ERRORS = (
    "error: closed",
    "Connection reset by peer",
    "Broken pipe",
    "device offline",
)
_ADB_TIMEOUT = 120  # seconds per adb call; WiFi ADB can hang silently
_ADB_RETRIES = 2


def check_adb(logger) -> bool:
    if shutil.which("adb"):
        return True
    logger.error(
        "ADB not found on PATH. Install Android SDK Platform Tools and add it to your PATH.\n"
        "  Download: https://developer.android.com/tools/releases/platform-tools"
    )
    return False


def _parse_adb_devices(stdout: str) -> list[tuple[str, str]]:
    devices = []
    for line in stdout.splitlines():
        trimmed = line.strip()
        if not trimmed or trimmed.startswith("*") or trimmed.startswith("List of devices"):
            continue
        parts = trimmed.split()
        if len(parts) >= 2:
            serial = parts[0]
            if parts[1] == "no" and len(parts) >= 3 and parts[2].startswith("permission"):
                state = "no permissions"
            else:
                state = parts[1]
            devices.append((serial, state))
    return devices


def _query_adb_devices(logger) -> list[tuple[str, str]] | None:
    try:
        result = subprocess.run(
            ["adb", "devices"],
            capture_output=True,
            check=True,
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"'adb devices' failed: {e.stderr.decode(errors='replace').strip()}")
        return None
    return _parse_adb_devices(result.stdout.decode(errors="replace"))


def _confirm_restart_prompt(prompt: str) -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        response = input(prompt)
        return response.strip().lower() in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False


def _prompt_user_to_continue(prompt: str) -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        input(prompt)
        return True
    except (EOFError, KeyboardInterrupt):
        return False


def _restart_adb_server(logger) -> None:
    logger.info("Restarting ADB server...")
    try:
        subprocess.run(
            ["adb", "kill-server"],
            check=True,
            capture_output=True,
            timeout=_ADB_TIMEOUT,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        logger.warning(f"'adb kill-server' warning: {e}")
    time.sleep(2)


def check_device_connected(logger) -> bool:
    devices = _query_adb_devices(logger)
    if devices is None:
        return False

    if not devices:
        logger.error(
            "No Android device detected over USB or Wi-Fi. Ensure:\n"
            "  1. The device is connected via a data-capable USB cable\n"
            "  2. USB debugging is enabled in Settings > Developer options"
        )
        return False

    if len(devices) > 1:
        summary = ", ".join(f"{s} ({st})" for s, st in devices)
        logger.error(
            f"Multiple Android devices detected: {summary}.\n"
            "  Disconnect all devices except the one you wish to archive."
        )
        return False

    serial, state = devices[0]
    if state == "device":
        logger.info(f"Android device connected and authorized: {serial}")
        return True

    if state == "unauthorized":
        logger.warning(
            f"Android device '{serial}' is connected but unauthorized "
            "(the USB debugging authorization prompt was not accepted on the phone)."
        )
        prompt_msg = "Restart ADB server to re-trigger authorization prompt on your phone? [y/N]: "
        if _confirm_restart_prompt(prompt_msg):
            logger.info("Restarting ADB server... Please ensure your phone screen is unlocked.")
            _restart_adb_server(logger)
            _query_adb_devices(logger)
            continue_prompt = (
                "Unlock your phone, tap 'Allow USB debugging' (check 'Always allow'), "
                "then press Enter to continue: "
            )
            if not _prompt_user_to_continue(continue_prompt):
                logger.error("Authorization check cancelled by user.")
                return False
            devices_after = _query_adb_devices(logger)
            if devices_after and len(devices_after) == 1 and devices_after[0][1] == "device":
                logger.info(f"Android device connected and authorized: {devices_after[0][0]}")
                return True
            logger.error(
                f"Device '{serial}' is still unauthorized.\n"
                "  1. Unlock your phone screen and look for the 'Allow USB debugging' prompt\n"
                "  2. In Settings > Developer options, tap 'Revoke USB debugging authorizations'\n"
                "  3. Ensure USB connection mode is set to 'File Transfer (MTP)' rather than 'Charge only'"
            )
            return False

        logger.error(
            f"Android device '{serial}' is connected but unauthorized.\n"
            "  Unlock your phone and accept the 'Allow USB debugging' prompt "
            "(check 'Always allow from this computer')."
        )
        return False

    if state == "offline":
        logger.error(
            f"Android device '{serial}' is connected but offline.\n"
            "  Reconnect the USB cable, toggle USB debugging off and on in Developer options, "
            "or restart the ADB server ('adb kill-server')."
        )
        return False

    if state == "no permissions":
        logger.error(
            f"Android device '{serial}' detected, but ADB lacks host permissions to access it.\n"
            "  Check your USB permissions or driver (on Linux, check udev rules / plugdev group)."
        )
        return False

    if state in ("recovery", "sideload", "bootloader"):
        logger.error(
            f"Android device '{serial}' is in '{state}' mode.\n"
            "  Normal Android OS is required for WhatsApp extraction."
        )
        return False

    logger.error(
        f"Android device '{serial}' is in unexpected state '{state}'.\n"
        "  Reconnect the device and ensure USB debugging is enabled."
    )
    return False


def pull_msgstore(output_dir: str, business: bool = False, logger=None) -> str:
    remote = _MSGSTORE_BUSINESS_PATH if business else _MSGSTORE_PATH
    dest = os.path.join(output_dir, "msgstore.db.crypt15")
    if logger:
        logger.info("Pulling msgstore backup via ADB...")
    try:
        subprocess.run(
            ["adb", "pull", remote, dest],
            check=True,
            stderr=subprocess.PIPE,
        )
    except subprocess.CalledProcessError as e:
        if logger:
            stderr = e.stderr.decode(errors="replace").strip() if e.stderr else ""
            if "does not exist" in stderr or "No such file" in stderr:
                logger.error(
                    f"WhatsApp backup file not found on device at '{remote}'.\n"
                    "  Ensure 'End-to-end encrypted backup' is enabled in WhatsApp "
                    "(Settings > Chats > Chat backup) and a backup has been created."
                )
            elif "Permission denied" in stderr or "open failed" in stderr:
                logger.error(f"Permission denied accessing '{remote}' on device.")
            elif "device offline" in stderr or "device not found" in stderr:
                logger.error(f"Android device disconnected or went offline during pull: {stderr}")
            else:
                logger.error(f"ADB pull failed: {stderr}")
        raise
    return dest


def enumerate_remote_backup_files(
    business: bool, logger: logging.Logger
) -> tuple[str | None, list[str]]:
    """Discover the base msgstore.db.crypt15 and any msgstore-increment-*.crypt15 on the device."""

    remote_dir = (
        posixpath.dirname(_MSGSTORE_BUSINESS_PATH)
        if business
        else posixpath.dirname(_MSGSTORE_PATH)
    )

    logger.info(f"Checking for database backups in {remote_dir}...")
    try:
        result = _run_adb(
            ["adb", "shell", f'ls -1 "{remote_dir}"'],
            logger,
        )
    except Exception as e:
        logger.warning(f"Failed to list remote backups in {remote_dir}: {e}")
        return None, []

    lines = result.stdout.decode(errors="replace").splitlines()
    base_file = None
    rotated_base_candidates = []
    remote_inc_candidates = []
    inc_pattern = re.compile(r"msgstore-increment-(\d+)")
    rotated_base_pattern = re.compile(
        r"^msgstore-(\d{4}-\d{2}-\d{2}(?:\.\d+)?)\.db\.crypt(?:14|15)$"
    )

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue
        if line in ("msgstore.db.crypt15", "msgstore.db.crypt14"):
            base_file = f"{remote_dir}/{line}"
        elif rotated_base_pattern.match(line):
            rotated_base_candidates.append(f"{remote_dir}/{line}")
        elif inc_pattern.search(line) and (line.endswith(".crypt15") or line.endswith(".crypt14")):
            remote_inc_candidates.append(f"{remote_dir}/{line}")

    if base_file is None and rotated_base_candidates:
        rotated_base_candidates.sort()
        base_file = rotated_base_candidates[-1]

    sorted_inc_paths = filter_active_increments(remote_inc_candidates, base_file)

    if len(remote_inc_candidates) > len(sorted_inc_paths):
        logger.info(
            f"Filtered {len(remote_inc_candidates)} remote increments down to "
            f"{len(sorted_inc_paths)} active generation increment(s)."
        )

    if base_file is None:
        logger.warning(f"Base msgstore backup not found in {remote_dir}.")
    else:
        logger.info(
            f"Found base backup '{posixpath.basename(base_file)}' and "
            f"{len(sorted_inc_paths)} active incremental backup(s)."
        )

    return base_file, sorted_inc_paths


def pull_msgstore_and_increments(
    staging_dir: str, business: bool, logger: logging.Logger
) -> tuple[str, list[str]]:
    """Pull the base msgstore database and all active incremental diffs into staging_dir."""

    base_remote, inc_remotes = enumerate_remote_backup_files(business, logger)
    if base_remote is None:
        local_base = pull_msgstore(staging_dir, business, logger)
        return local_base, []

    os.makedirs(staging_dir, exist_ok=True)
    local_base = os.path.join(staging_dir, posixpath.basename(base_remote))
    logger.info(f"Pulling base msgstore '{posixpath.basename(base_remote)}'...")
    try:
        subprocess.run(
            ["adb", "pull", base_remote, local_base],
            check=True,
            stderr=subprocess.PIPE,
        )
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode(errors="replace").strip() if e.stderr else ""
        logger.error(f"Failed to pull base backup from '{base_remote}' via ADB: {stderr}")
        raise

    local_increments = []
    for inc_remote in inc_remotes:
        inc_name = posixpath.basename(inc_remote)
        local_inc = os.path.join(staging_dir, inc_name)
        logger.info(f"Pulling increment '{inc_name}'...")
        try:
            subprocess.run(
                ["adb", "pull", inc_remote, local_inc],
                check=True,
                stderr=subprocess.PIPE,
            )
            local_increments.append(local_inc)
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode(errors="replace").strip() if e.stderr else ""
            logger.error(f"Failed to pull increment '{inc_remote}' via ADB: {stderr}")
            raise

    return local_base, local_increments


def pull_contacts(output_dir: str, logger=None) -> str:
    dest = os.path.join(output_dir, "wa_contacts")
    if logger:
        logger.info("Pulling contacts via ADB...")
    try:
        result = subprocess.run(
            [
                "adb",
                "shell",
                "content",
                "query",
                "--uri",
                _CONTACTS_URI,
                "--projection",
                _CONTACTS_PROJECTION,
            ],
            capture_output=True,
            check=True,
        )
    except subprocess.CalledProcessError as e:
        if logger:
            logger.error(
                f"ADB contacts query failed.\n  {e.stderr.decode(errors='replace').strip()}"
            )
        raise

    lines = result.stdout.decode(errors="replace").splitlines()
    relevant_lines = [
        line
        for line in lines
        if "vnd.com.whatsapp" in line
        or "@s.whatsapp.net" in line
        or "vnd.android.cursor.item/phone_v2" in line
    ]
    # If no lines matched known mimetypes, write all lines as fallback
    output_lines = relevant_lines if relevant_lines else lines
    with open(dest, "w", encoding="utf-8") as f:
        f.write("\n".join(output_lines) + "\n")
    return dest


# ---------------------------------------------------------------------------
# ADB media pull helpers
# ---------------------------------------------------------------------------


def get_device_serial(logger) -> str:
    """Return the serial number of the connected ADB device."""
    result = subprocess.run(
        ["adb", "get-serialno"],
        capture_output=True,
        timeout=_ADB_TIMEOUT,
    )
    serial = result.stdout.decode(errors="replace").strip()
    if result.returncode != 0 or not serial or serial == "unknown":
        raise RuntimeError(
            f"Could not get device serial: {result.stderr.decode(errors='replace').strip()}"
        )
    logger.debug(f"Device serial: {serial}")
    return serial


def probe_md5_binary(logger) -> str:
    """Return the name of the md5 binary available on the device ('md5sum' or 'md5')."""
    result = subprocess.run(
        ["adb", "shell", "which md5sum || which md5"],
        capture_output=True,
        timeout=_ADB_TIMEOUT,
    )
    path = result.stdout.decode(errors="replace").strip().splitlines()
    if not path or result.returncode == 127:
        raise RuntimeError(
            "Neither md5sum nor md5 found on device — cannot verify file hashes for ADB pull."
        )
    binary = os.path.basename(path[0])
    logger.debug(f"md5 binary on device: {binary}")
    return binary


def _run_adb(cmd: list, logger) -> subprocess.CompletedProcess:
    """Run an ADB command with retries on transient connection errors."""
    last_exc = None
    for attempt in range(_ADB_RETRIES + 1):
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                timeout=_ADB_TIMEOUT,
            )
            if result.returncode == 0:
                return result
            stderr = result.stderr.decode(errors="replace")
            if any(e in stderr for e in _TRANSIENT_ERRORS):
                if attempt < _ADB_RETRIES:
                    logger.warning(
                        f"Transient ADB error (attempt {attempt + 1}/{_ADB_RETRIES + 1}): "
                        f"{stderr.strip()}"
                    )
                    time.sleep(2)
                    continue
            raise subprocess.CalledProcessError(
                result.returncode, cmd, result.stdout, result.stderr
            )
        except subprocess.TimeoutExpired as e:
            last_exc = e
            if attempt < _ADB_RETRIES:
                logger.warning(
                    f"ADB command timed out (attempt {attempt + 1}/{_ADB_RETRIES + 1}), retrying..."
                )
                time.sleep(2)
                continue
            raise RuntimeError(
                f"ADB command timed out after {_ADB_RETRIES + 1} attempts: {' '.join(cmd)}"
            ) from last_exc
    raise subprocess.CalledProcessError(1, cmd)


def _classify_adb_error(stderr: str) -> str:
    """Return a human-readable explanation of an ADB pull failure."""
    if "does not exist" in stderr:
        return "Remote path not found"
    if "Permission denied" in stderr or "open failed" in stderr:
        return "Permission denied — file not accessible without root"
    if "device not found" in stderr or "device offline" in stderr:
        return "Device disconnected or offline"
    if "No space left on device" in stderr:
        return "Host disk is full"
    return stderr.strip()


def enumerate_remote_files(wa_media_root: str, logger) -> list:
    """Return list of (remote_path, size_bytes) for all files under wa_media_root."""
    logger.info(f"Enumerating remote files under {wa_media_root}...")
    result = _run_adb(
        ["adb", "shell", f'find "{wa_media_root}" -type f -printf "%p\\t%s\\n"'],
        logger,
    )
    entries = []
    for line in result.stdout.decode(errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        # Filter find error lines mixed into stdout
        if "Permission denied" in line or "No such file or directory" in line:
            logger.debug(f"find: skipped inaccessible path: {line}")
            continue
        parts = line.rsplit("\t", 1)
        if len(parts) != 2:
            continue
        remote_path, size_str = parts
        try:
            entries.append((remote_path.strip(), int(size_str.strip())))
        except ValueError:
            logger.debug(f"find: could not parse size in line: {line!r}")
    logger.info(f"Found {len(entries)} files on device.")
    return entries


def _remote_md5(remote_path: str, md5_binary: str, logger) -> bytes:
    """Return the MD5 hash of a remote file as bytes."""
    result = _run_adb(
        ["adb", "shell", f'{md5_binary} "{remote_path}"'],
        logger,
    )
    out = result.stdout.decode(errors="replace").strip()
    # md5sum: "<hash>  <path>"; md5 (older): "<hash> <path>" or "<path>: <hash>"
    if ":" in out and not out.startswith("/"):
        # "<path>: <hash>" format
        hex_str = out.split(":", 1)[1].strip()
    else:
        hex_str = out.split()[0]
    return bytes.fromhex(hex_str)


def _staging_path(remote_path: str, remote_root: str, staging_dir: str) -> str:
    """Map a remote absolute path to a local staging path under Media/."""
    rel = remote_path[len(remote_root) :].lstrip("/")
    return os.path.join(staging_dir, "Media", rel.replace("/", os.sep))


def pull_media(
    staging_dir: str,
    business: bool,
    conn: sqlite3.Connection,
    logger,
    target_paths: set[str] | None,
) -> tuple:
    """
    Pull WhatsApp media from a connected device to staging_dir.

    staging_dir acts as a permanent 1:1 copy of the phone's WhatsApp storage
    (treated as wa_root during archiving; files are copied to the output folder
    and are not deleted).

    Returns (pulled, skipped, conflicts) where conflicts is a list of
    {'remote_path', 'remote_md5', 'archived_md5'} dicts.
    """
    from . import archive_db as _arc

    wa_media_root = _WA_BUSINESS_MEDIA_ROOT if business else _WA_MEDIA_ROOT
    os.makedirs(staging_dir, exist_ok=True)

    device_serial = get_device_serial(logger)
    md5_binary = probe_md5_binary(logger)

    # Clean up any partial files from a previous interrupted run
    partial_paths = _arc.get_adb_partial_paths(conn, device_serial)
    if partial_paths:
        logger.info(f"Cleaning {len(partial_paths)} partial file(s) from previous run...")
    for remote_path in partial_paths:
        local = _staging_path(remote_path, wa_media_root, staging_dir)
        if os.path.exists(local):
            os.remove(local)
            logger.debug(f"Removed partial: {local}")
        _arc.remove_adb_pull_state(conn, remote_path, device_serial)

    # Build filename index from archive DB for delta pre-filter
    filename_index = _arc.build_archive_filename_index(conn)

    # Enumerate remote files
    remote_files = enumerate_remote_files(wa_media_root, logger)
    if not remote_files:
        logger.warning("No media files found on device.")
        return 0, 0, []

    if target_paths is not None:
        prefix_len = len(wa_media_root)
        candidate_files = []
        for remote_path, remote_size in remote_files:
            rel = remote_path[prefix_len:].lstrip("/")
            clean_rel = rel.replace("\\", "/")
            db_path = f"Media/{clean_rel}"
            if db_path in target_paths:
                candidate_files.append((remote_path, remote_size))
        logger.info(
            f"Filtered {len(remote_files):,} remote file(s) to "
            f"{len(candidate_files):,} file(s) matching filter."
        )
        remote_files = candidate_files
        if not remote_files:
            logger.info("No remote files match the filter.")
            return 0, 0, []

    logger.info(
        f"Found {len(remote_files):,} file(s) to evaluate. "
        "If your WhatsApp media folder is several gigabytes, this can take hours, "
        "especially if you have many voice messages or other small files."
    )

    done_paths = _arc.get_adb_done_paths(conn, device_serial)

    pull_list = []
    skip_count = 0
    conflicts = []

    progress_eval = ProgressReporter("Evaluating media", len(remote_files), logger, sys.stderr, 0.2)

    for i, (remote_path, remote_size) in enumerate(remote_files, 1):
        if remote_path in done_paths:
            skip_count += 1
            progress_eval.update(
                i, {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
            )
            continue
        basename = os.path.basename(remote_path)
        if basename not in filename_index:
            pull_list.append((remote_path, remote_size))
            progress_eval.update(
                i, {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
            )
            continue
        db_size, db_md5 = filename_index[basename]
        if db_size is not None and db_size != remote_size:
            pull_list.append((remote_path, remote_size))
            progress_eval.update(
                i, {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
            )
            continue
        # Size matches (or DB has no size for old record): verify via remote md5
        try:
            remote_md5 = _remote_md5(remote_path, md5_binary, logger)
        except Exception as e:
            logger.warning(f"Could not hash remote file {remote_path}: {e} — will pull")
            pull_list.append((remote_path, remote_size))
            progress_eval.update(
                i, {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
            )
            continue
        if remote_md5 == db_md5:
            skip_count += 1
            _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "done")
        else:
            conflicts.append(
                {
                    "remote_path": remote_path,
                    "remote_md5": remote_md5.hex(),
                    "archived_md5": db_md5.hex(),
                }
            )
            logger.warning(
                f"CONFLICT: {basename} has different content on device vs archive "
                f"(same {'name+size' if db_size == remote_size else 'name'}) — skipped"
            )
        progress_eval.update(
            i, {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
        )

    progress_eval.finish(
        {"To pull": len(pull_list), "Skipped": skip_count, "Conflicts": len(conflicts)}
    )

    logger.info(
        f"Delta pre-filter: {len(pull_list):,} to pull, "
        f"{skip_count:,} already archived, "
        f"{len(conflicts):,} conflict(s)."
    )

    pulled = 0
    failed = 0
    progress_pull = ProgressReporter("Pulling media", len(pull_list), logger, sys.stderr, 0.2)

    for i, (remote_path, remote_size) in enumerate(pull_list, 1):
        local = _staging_path(remote_path, wa_media_root, staging_dir)
        os.makedirs(os.path.dirname(local), exist_ok=True)
        _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
        try:
            _run_adb(["adb", "pull", remote_path, local], logger)
        except KeyboardInterrupt:
            _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
            progress_pull.finish({"Pulled": pulled, "Failed": failed})
            raise
        except Exception as e:
            stderr = ""
            if hasattr(e, "stderr") and e.stderr:
                stderr = e.stderr.decode(errors="replace")
            reason = _classify_adb_error(stderr)
            if (
                "device not found" in stderr
                or "device offline" in stderr
                or "error: closed" in stderr
            ):
                _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
                progress_pull.finish({"Pulled": pulled, "Failed": failed})
                raise RuntimeError(
                    f"Device disconnected during pull of {remote_path}: {reason}"
                ) from e
            logger.error(f"Failed to pull {remote_path}: {reason}")
            _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
            failed += 1
            progress_pull.update(i, {"Pulled": pulled, "Failed": failed})
            continue
        if not os.path.exists(local):
            logger.error(f"ADB pull reported success but file not found locally: {local}")
            _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
            failed += 1
            progress_pull.update(i, {"Pulled": pulled, "Failed": failed})
            continue
        if os.path.getsize(local) != remote_size:
            logger.warning(
                f"Pulled file is truncated (expected {remote_size} B, "
                f"got {os.path.getsize(local)} B): {remote_path}"
            )
            _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "partial")
            failed += 1
            progress_pull.update(i, {"Pulled": pulled, "Failed": failed})
            continue
        _arc.upsert_adb_pull_state(conn, remote_path, device_serial, "done")
        pulled += 1
        logger.debug(f"Pulled: {remote_path}")
        progress_pull.update(i, {"Pulled": pulled, "Failed": failed})

    progress_pull.finish({"Pulled": pulled, "Failed": failed})

    logger.info(f"Pull complete: {pulled:,} file(s) pulled.")
    return pulled, skip_count, conflicts


def write_adb_conflicts_report(report_path: str, conflicts: list, logger):
    """Write ADB pull conflicts to a CSV file — requires user intervention."""
    if not conflicts:
        return
    fieldnames = ["remote_path", "remote_md5", "archived_md5"]
    with open(report_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(conflicts)
    logger.warning(
        f"ADB conflicts report written to: {report_path} "
        f"({len(conflicts)} file(s) with same name/size but different content — "
        "review and resolve manually)"
    )
